{
gStyle->SetOptStat(0);
gStyle->SetOptTitle(0);

Int_t n = 15;

Float_t Xmin[n] = {0.02,0.25,0.075,0.09,0.2,0.05,0.08,0.2,0.07,0.03,0.003,5.0E-05,0.0035,0.01,0.03};
Float_t Xmax[n] = {0.20,0.90,0.860,0.90,0.5,0.65,0.70,0.7,0.65,0.60,0.100,0.25000,0.6500,0.60,0.30};

Float_t Qmin[n] = {0.4,3.,9.0,26.,46.,14.,4.,0.3,0.01,0.5,0.05,16.};
Float_t Qmax[n] = {1.6,20,170,200,200,200,40,3.2,60.0,100,30.0,400};

   TCanvas *c1 = new TCanvas("c1", "c1",10,50,556,500);
   c1->ToggleEventStatus();
   c1->Range(-5.6295,-3.74586,0.629496,3.74586);
   c1->SetFillColor(0);
   c1->SetBorderMode(0);
   c1->SetBorderSize(1);
   c1->SetLogx();
   c1->SetLogy();
   c1->SetFrameFillColor(10);
   c1->SetFrameBorderMode(10);

   Float_t logxmin, logxmax,
   Float_t logqmin, logqmax;
Axis_t xmin = 1E-10; //TMath::Min
Axis_t xmax = 1. ;
Int_t ncx = 100;
Axis_t ymin = 1E-05; //TMath::Min
Axis_t ymax = 10000000. ;
Int_t ncy = 100;

TH2F *frame = new TH2F("frame","",ncx,xmin,xmax,ncy,ymin,ymax);  
frame->Draw("");

Int_t i=0; Int_t transp_col=0;
for (i=0;i<n;i++)
{
logxmin = log(Xmin[i]); logqmin = log(Qmin[i]);
logxmax = log(Xmax[i]); logqmax = log(Qmax[i]);
//  TBox *box_1 = new TBox(Xmin[i],Qmin[i],Xmax[i],Qmax[i]);
  TBox *box_1 = new TBox(logxmin,logqmin,logxmax,logqmax);
  // TGraph *box_[i] = new TGraph();
  //box_1 = new TGraph(n,Xmin,Qmax);
 transp_col = 3000+i;
 box_1->SetFillColor((40+i));
 box_1->SetFillStyle(transp_col);
 box_1->Draw("AF");
}

}
