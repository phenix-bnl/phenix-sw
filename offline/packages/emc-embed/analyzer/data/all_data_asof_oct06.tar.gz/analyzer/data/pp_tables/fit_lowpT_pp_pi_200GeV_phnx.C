void fit_lowpT_pp_pi_200GeV_phnx()
{
  gSystem->Load("libemcAnalyzer"); emcAnalyzer e; TGraphErrors *eband;e.keepPlot(false);
  e.keepPlot();
  e.setFit(false);

  TGraphErrors *pip =e.plot_spectrum_from_ascii("pip_pp_200GeV_xsect_phnx_run2.txt",eband);
  TGraphErrors *pim =e.plot_spectrum_from_ascii("pim_pp_200GeV_xsect_phnx_run2.txt",eband);
  TGraphErrors *pichg=(TGraphErrors*)emcAnalyzerUtils::add(pim,pip);
  emcAnalyzerUtils::scale(*pichg,0.5);
  pichg->SetName("pichg");
  pichg->SetTitle("pichg");
  pichg->Draw("P");

  double pi0_pt[5]={ 1.215, 1.719,  2.223,  2.726,  3.228};
  double pi0_ept[5]={ 0.05, 0.05,  0.05,  0.05,  0.05};
  double pi0_xs[5]={ 3.729e-01, 5.954e-02, 1.216e-02, 3.056e-03, 9.772e-04};
  double pi0_estat[5]={ 1.791e-03, 4.687e-04, 1.626e-04, 6.972e-05, 3.435e-05};
  double pi0_esyst[5]={ 3.230e-02, 4.615e-03, 9.483e-04, 2.437e-04, 8.017e-05};
  double pi0_exs[5];
  for (int i=0;i<5;i++) { pi0_exs[i]=sqrt(pi0_estat[i]*pi0_estat[i]+pi0_esyst[i]*pi0_esyst[i]);}
  TGraphErrors *pi0 = new TGraphErrors(5,pi0_pt,pi0_xs,pi0_ept,pi0_exs);
  pi0->Draw("P");

  TF1 user("user","[0]*exp(-x/[1])",0,0.75);
  user.SetParameters(300,1/6.);
  pi->Fit("user","REIL");

}
