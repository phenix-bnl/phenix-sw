deflorian(){

//_____________________________________________________________________________

TCanvas *c1 = new TCanvas("c1", "c1",10,50,750,750);
c1->ToggleEventStatus();
c1->Range(-5.6295,-3.74586,0.629496,3.74586);
c1->SetFillColor(0);
c1->SetBorderMode(0);
c1->SetBorderSize(1);
c1->SetLogx();
c1->SetLogy();
c1->SetFrameFillColor(0);
c1->SetFrameBorderMode(0);

Float_t logxmin, logxmax;
Float_t logqmin, logqmax;

Axis_t xmin = 1E-6; //TMath::Min
Axis_t xmax = 1. ;
Int_t ncx = 100;
Axis_t ymin = 1E-02; //TMath::Min
Axis_t ymax = 10000. ;
Int_t ncy = 100;

TH2F *frame = new TH2F("frame","",ncx,xmin,xmax,ncy,ymin,ymax);  
frame->Draw("");

//_____________________________________________________________________________
// NMC
//

 int NMC_marker=20;
 int NMC_size=1.0;
 int NMC_col=2;

// He_NMC (18),  C_NMC (18), Ca_NMC (18)

 int N = 18;

double x_NMC[] = { 0.0035, 0.0055, 0.0085, 0.0125, 0.0175, 0.025,
		   0.035, 0.045, 0.055, 0.07, 0.09, 0.125, 0.175,
		   0.25, 0.35, 0.45, 0.55, 0.65};

double Q2_He_NMC[] = { 0.77,1.3,1.8,2.4,3.0,3.8,4.7,5.6,6.3,7.3,8.7, 11, 14, 19, 24, 31,38,44}; 

TGraph *x_Q2_He_NMC = new TGraph( N, x_NMC, Q2_He_NMC);
x_Q2_He_NMC->SetTitle("x_Q2_He_NMC");
x_Q2_He_NMC->SetName("");
x_Q2_He_NMC->SetMarkerStyle(NMC_marker);
x_Q2_He_NMC->SetMarkerSize(NMC_size);
x_Q2_He_NMC->SetMarkerColor(NMC_col);
x_Q2_He_NMC->Draw("P");

double Q2_C_NMC[] = { 0.74,1.2,1.7,2.3,3.0,3.8,4.9, 6.0, 7.2, 8.8, 11, 14, 17, 21, 26,31,37,44};

TGraph *x_Q2_C_NMC = new TGraph( N, x_NMC, Q2_C_NMC);
x_Q2_C_NMC->SetTitle("x_Q2_C_NMC");
x_Q2_C_NMC->SetName("");
x_Q2_C_NMC->SetMarkerStyle(NMC_marker);
x_Q2_C_NMC->SetMarkerSize(NMC_size);
x_Q2_C_NMC->SetMarkerColor(NMC_col);
x_Q2_C_NMC->Draw("P");

double Q2_Ca_NMC[] = { 0.60, 0.94, 1.4, 1.9, 2.5, 3.4, 4.7, 5.7, 6.8, 8.1, 9.7, 12, 14, 19, 24, 30, 35, 41};

TGraph *x_Q2_Ca_NMC = new TGraph( N, x_NMC, Q2_Ca_NMC);
x_Q2_Ca_NMC->SetTitle("x_Q2_Ca_NMC");
x_Q2_Ca_NMC->SetName("");
x_Q2_Ca_NMC->SetMarkerStyle(NMC_marker);
x_Q2_Ca_NMC->SetMarkerSize(NMC_size);
x_Q2_Ca_NMC->SetMarkerColor(NMC_col);
x_Q2_Ca_NMC->Draw("P");

// BeC_NMC (15)

N = 15;

double x_BeC_NMC[] = { 0.0125,0.0175,0.025,0.035,0.045,0.055,0.07,
		       0.09,0.125,0.175,0.25,0.35,0.45,0.55, 0.70};

double Q2_BeC_NMC[] = { 3.4,4.5,6.0,8.0,9.8,11.4,13.8,16.8,21.4,27.6,35.5,45.4,53.9,60.5,66.7}; 

TGraph *x_Q2_BeC_NMC = new TGraph( N, x_BeC_NMC, Q2_BeC_NMC);
x_Q2_BeC_NMC->SetTitle("x_Q2_BeC_NMC");
x_Q2_BeC_NMC->SetName("");
x_Q2_BeC_NMC->SetMarkerStyle(NMC_marker);
x_Q2_BeC_NMC->SetMarkerSize(NMC_size);
x_Q2_BeC_NMC->SetMarkerColor(NMC_col);
x_Q2_BeC_NMC->Draw("P");

// AlC_NMC (15)

double x_AlC_NMC[] = { 0.0125,0.0175,0.025,0.035,0.045,0.055,0.07,
		       0.09,0.125,0.175,0.25,0.35,0.45,0.55, 0.70};

double Q2_AlC_NMC[] = { 3.4,4.5,6.1,8.0,9.8,11.6,13.9,16.9,21.3,
			27.4,35.5,45.3,52.9,58.2,63.9}; 

TGraph *x_Q2_AlC_NMC = new TGraph( N, x_AlC_NMC, Q2_AlC_NMC);
x_Q2_AlC_NMC->SetTitle("x_Q2_AlC_NMC");
x_Q2_AlC_NMC->SetName("");
x_Q2_AlC_NMC->SetMarkerStyle(NMC_marker);
x_Q2_AlC_NMC->SetMarkerSize(NMC_size);
x_Q2_AlC_NMC->SetMarkerColor(NMC_col);
x_Q2_AlC_NMC->Draw("P");

// CaC_NMC (15)

double x_CaC_NMC[] = { 0.0125,0.0175,0.025,0.035,0.045,0.055,0.07,
		       0.09,0.125,0.175,0.25,0.35,0.45,0.55, 0.70};

double Q2_CaC_NMC[] = { 3.4,4.5,6.0,7.9,9.7,11.4,13.8,16.7,21.2,
			27.4,35.3,45.3,53.6,60.3,66.4}; 

TGraph *x_Q2_CaC_NMC = new TGraph( N, x_CaC_NMC, Q2_CaC_NMC);
x_Q2_CaC_NMC->SetTitle("x_Q2_CaC_NMC");
x_Q2_CaC_NMC->SetName("");
x_Q2_CaC_NMC->SetMarkerStyle(NMC_marker);
x_Q2_CaC_NMC->SetMarkerSize(NMC_size);
x_Q2_CaC_NMC->SetMarkerColor(NMC_col);
x_Q2_CaC_NMC->Draw("P");

// FeC_NMC (15)

double x_FeC_NMC[] = { 0.0125,0.0175,0.025,0.035,0.045,0.055,0.07,
		       0.09,0.125,0.175,0.25,0.35,0.45,0.55, 0.70};

double Q2_FeC_NMC[] = { 3.4,4.5,6.1,8.1,10.0,11.8,14.1,17.1,21.7,
			27.8,35.7,45.4,53.6,60.3,66.6}; 

TGraph *x_Q2_FeC_NMC = new TGraph( N, x_FeC_NMC, Q2_FeC_NMC);
x_Q2_FeC_NMC->SetTitle("x_Q2_FeC_NMC");
x_Q2_FeC_NMC->SetName("");
x_Q2_FeC_NMC->SetMarkerStyle(NMC_marker);
x_Q2_FeC_NMC->SetMarkerSize(NMC_size);
x_Q2_FeC_NMC->SetMarkerColor(NMC_col);
x_Q2_FeC_NMC->Draw("P");

// PbC_NMC (15)

double x_PbC_NMC[] = { 0.0125,0.0175,0.025,0.035,0.045,0.055,0.07,
		       0.09,0.125,0.175,0.25,0.35,0.45,0.55, 0.70};

double Q2_PbC_NMC[] = { 3.4,4.5,6.1,8.0,9.8,11.6,13.9,16.9,21.4,
			27.5,35.5,45.3,53.6,60.0,66.1}; 

TGraph *x_Q2_PbC_NMC = new TGraph( N, x_PbC_NMC, Q2_PbC_NMC);
x_Q2_PbC_NMC->SetTitle("x_Q2_PbC_NMC");
x_Q2_PbC_NMC->SetName("");
x_Q2_PbC_NMC->SetMarkerStyle(NMC_marker);
x_Q2_PbC_NMC->SetMarkerSize(NMC_size);
x_Q2_PbC_NMC->SetMarkerColor(NMC_col);
x_Q2_PbC_NMC->Draw("P");

// SnC_NMC (15) (average)

double x_SnCC_NMC[] = { 0.0125,0.0175,0.025,0.035,0.045,0.055,0.07,
			0.09,0.125,0.175,0.25,0.35,0.45,0.55, 0.70};

double Q2_SnCC_NMC[] = { 3.2,4.3,5.6,7.3,8.6,9.8,11.2,12.7,14.8,
			 17.3,20.5,25.1,32.0,43.9,56.8}; 

TGraph *x_Q2_SnCC_NMC = new TGraph( N, x_SnCC_NMC, Q2_SnCC_NMC);
x_Q2_SnCC_NMC->SetTitle("x_Q2_SnCC_NMC");
x_Q2_SnCC_NMC->SetName("");
x_Q2_SnCC_NMC->SetMarkerStyle(NMC_marker);
x_Q2_SnCC_NMC->SetMarkerSize(NMC_size);
x_Q2_SnCC_NMC->SetMarkerColor(NMC_col);
x_Q2_SnCC_NMC->Draw("P");

// SnC_NMC (145) (x=0.125 Q2=2.3 excluded)

N = 145;
double x_SnC_NMC[] = { 0.0125,0.0125,0.0125,0.0125,0.0125,0.0125,
		       0.0125,0.0125,0.0175,0.0175,0.0175,0.0175,0.0175,
		       0.0175,0.0175,0.0175,0.0175,0.025, 0.025, 0.025,
		       0.025, 0.025, 0.025, 0.025, 0.025, 0.025, 0.035,0.035,
		       0.035, 0.035, 0.035, 0.035, 0.035, 0.035, 0.035,0.035,0.035,
		       0.045, 0.045, 0.045, 0.045, 0.045, 0.045, 0.045,0.045,0.045,
		       0.045, 0.045, 0.055, 0.055, 0.055, 0.055, 0.055,0.055,0.055,
		       0.055, 0.055, 0.055, 0.055, 0.070, 0.070, 0.070,0.070,0.070,
		       0.070, 0.070, 0.070, 0.070, 0.070, 0.070, 0.070,0.090,0.090,
		       0.090, 0.090, 0.090, 0.090, 0.090, 0.090, 0.090,0.090,0.090,
		       0.090, 0.125, 0.125, 0.125, 0.125, 0.125, 0.125,0.125,0.125,
		       0.125, 0.125, 0.125, 0.125, 0.125, 0.175, 0.175,0.175,0.175,
		       0.175, 0.175, 0.175, 0.175, 0.175, 0.175, 0.175,0.175,0.250,
		       0.250, 0.250, 0.250, 0.250, 0.250, 0.250, 0.250,0.250,0.250,
		       0.250, 0.350, 0.350, 0.350, 0.350, 0.350, 0.350,0.350,0.350,
		       0.350, 0.450, 0.450, 0.450, 0.450, 0.450, 0.450,0.450,0.550,
		       0.550, 0.550, 0.550, 0.550, 0.550, 0.700, 0.700,0.700,0.700}; 

double Q2_SnC_NMC[] = { 1.3,1.8,2.3,2.8,3.5,4.5,5.5,7.0,
			1.3,1.8,2.3,2.8,3.5,4.5,5.5,7.0,9.0, 
			1.8,2.3,2.8,3.5,4.5,5.5,7.0,9.0,11.5,
			1.8,2.3,2.8,3.5,4.5,5.5,7.0,9.0,11.5,15.0,20.0,
			1.8,2.3,2.8,3.5,4.5,5.5,7.0,9.0,11.5,15.0,20.0,
			2.3,2.8,3.5,4.5,5.5,7.0,9.0,11.5,15.0,20.0,27.0,
			2.3,2.8,3.5,4.5,5.5,7.0,9.0,11.5,15.0,20.0,27.0,36.0,
			2.3,2.8,3.5,4.5,5.5,7.0,9.0,11.5,15.0,20.0,27.0,36.0,
			2.8,3.5,4.5,5.5,7.0,9.0,11.5,15.0,20.0,27.0,36.0,48.0,65.0,
			3.5,4.5,5.5,7.0,9.0,11.5,15.0,20.0,27.0,36.0,48.0,65.0,
			5.5,7.0,9.0,11.5,15.0,20.0,27.0,36.0,48.0,65.0,110.0,
			9.0,11.5,15.0,20.0,27.0,36.0,48.0,65.0,110.0,
			15.0,20.0,27.0,36.0,48.0,65.0,110.0,
			20.0,27.0,36.0,48.0,65.0,110.0,
			36.0,48.0,65.0,110.0};

TGraph *x_Q2_SnC_NMC = new TGraph( N, x_SnC_NMC, Q2_SnC_NMC);
x_Q2_SnC_NMC->SetTitle("x_Q2_SnC_NMC");
x_Q2_SnC_NMC->SetName("");
x_Q2_SnC_NMC->SetMarkerStyle(NMC_marker);
x_Q2_SnC_NMC->SetMarkerSize(NMC_size);
x_Q2_SnC_NMC->SetMarkerColor(NMC_col);
x_Q2_SnC_NMC->Draw("P");

//_____________________________________________________________________________
// E139
//

 int E139_marker=29;
 int E139_size=2.0;
 int E139_col=8;

// He_E139 (18)

N = 18;

double x_He_E139[] = { 0.13,0.22,0.22,0.30,0.30,0.40,0.40,0.40,
		       0.50,0.50,0.50,0.50,0.60,0.60,0.60,0.70,0.70,0.80};

double Q2_He_E139[] = { 2.0 ,2.0, 5.0, 2.0, 5.0, 2.0 , 5.0,10.0, 
			2.0, 5.0, 5.0,10.0, 5.0,10.0,15.0, 5.0,10.0,10.0};

TGraph *x_Q2_He_E139 = new TGraph( N, x_He_E139, Q2_He_E139);
x_Q2_He_E139->SetTitle("x_Q2_He_E139");
x_Q2_He_E139->SetName("");
x_Q2_He_E139->SetMarkerStyle(E139_marker);
x_Q2_He_E139->SetMarkerSize(E139_size);
x_Q2_He_E139->SetMarkerColor(E139_col);
x_Q2_He_E139->Draw("P");


// Be_E139 (17)

N = 17;

double x_Be_E139[] = { 0.13,0.22,0.22,0.30,0.30,0.40,0.40,0.40,
		       0.50,0.50,0.50,0.60,0.60,0.60,0.70,0.70,0.80};

double Q2_Be_E139[] = { 2.0 ,2.0, 5.0, 2.0, 5.0, 2.0 , 5.0,10.0, 
			2.0, 5.0,10.0, 5.0,10.0,15.0, 5.0,10.0,10.0};

TGraph *x_Q2_Be_E139 = new TGraph( N, x_Be_E139, Q2_Be_E139);
x_Q2_Be_E139->SetTitle("x_Q2_Be_E139");
x_Q2_Be_E139->SetName("");
x_Q2_Be_E139->SetMarkerStyle(E139_marker);
x_Q2_Be_E139->SetMarkerSize(E139_size);
x_Q2_Be_E139->SetMarkerColor(E139_col);
x_Q2_Be_E139->Draw("P");

// C_E139 (7)

N = 7;

double x_C_E139[] = { 0.22 ,0.30 ,0.40 ,0.50 ,0.60 ,0.60 ,0.70};

double Q2_C_E139[] = { 5.0, 5.0, 5.0 ,5.0 ,5.0 ,10.0 ,5.0};

TGraph *x_Q2_C_E139 = new TGraph( N, x_C_E139, Q2_C_E139);
x_Q2_C_E139->SetTitle("x_Q2_C_E139");
x_Q2_C_E139->SetName("");
x_Q2_C_E139->SetMarkerStyle(E139_marker);
x_Q2_C_E139->SetMarkerSize(E139_size);
x_Q2_C_E139->SetMarkerColor(E139_col);
x_Q2_C_E139->Draw("P");

// Al_E139 (17)

N = 17;

double x_Al_E139[] = { 0.13,0.22,0.22,0.30,0.30,0.40,0.40,0.40,
		       0.50,0.50,0.50,0.60,0.60,0.60,0.70,0.70,0.80};

double Q2_Al_E139[] = { 2.0 ,2.0, 5.0, 2.0, 5.0, 2.0 , 5.0,10.0, 
			2.0, 5.0,10.0, 5.0,10.0,15.0, 5.0,10.0,10.0};

TGraph *x_Q2_Al_E139 = new TGraph( N, x_Al_E139, Q2_Al_E139);
x_Q2_Al_E139->SetTitle("x_Q2_Al_E139");
x_Q2_Al_E139->SetName("");
x_Q2_Al_E139->SetMarkerStyle(E139_marker);
x_Q2_Al_E139->SetMarkerSize(E139_size);
x_Q2_Al_E139->SetMarkerColor(E139_col);
x_Q2_Al_E139->Draw("P");

// Ca_E139 (7)

N = 7;

double x_Ca_E139[] = { 0.22 ,0.30 ,0.40 ,0.50 ,0.60 ,0.60 ,0.70};

double Q2_Ca_E139[] = { 5.0, 5.0, 5.0 ,5.0 ,5.0 ,10.0 ,5.0};

TGraph *x_Q2_Ca_E139 = new TGraph( N, x_Ca_E139, Q2_Ca_E139);
x_Q2_Ca_E139->SetTitle("x_Q2_Ca_E139");
x_Q2_Ca_E139->SetName("");
x_Q2_Ca_E139->SetMarkerStyle(E139_marker);
x_Q2_Ca_E139->SetMarkerSize(E139_size);
x_Q2_Ca_E139->SetMarkerColor(E139_col);
x_Q2_Ca_E139->Draw("P");

// Fe_E139 (23)

N = 23;

double x_Fe_E139[] = { 0.089,0.13,0.14,0.22,0.22,0.30,0.30,0.30,
		       0.30 ,0.40,0.40,0.40,0.50,0.50,0.50,0.50,
		       0.60 ,0.60,0.60,0.70,0.70,0.70,0.80};

double Q2_Fe_E139[] = { 2.0 ,2.0 ,5.0 ,2.0 ,5.0 ,0.2, 5.0 ,5.0 ,
			10.0 ,2.0 ,5.0 ,10.0,2.0, 5.0, 5.0 ,10.0, 
			5.0 ,10.0,15.0,5.0 ,5.0,10.0,10.0};

TGraph *x_Q2_Fe_E139 = new TGraph( N, x_Fe_E139, Q2_Fe_E139);
x_Q2_Fe_E139->SetTitle("x_Q2_Fe_E139");
x_Q2_Fe_E139->SetName("");
x_Q2_Fe_E139->SetMarkerStyle(E139_marker);
x_Q2_Fe_E139->SetMarkerSize(E139_size);
x_Q2_Fe_E139->SetMarkerColor(E139_col);
x_Q2_Fe_E139->Draw("P");

// Ag_E139 (7)

N = 7;

double x_Ag_E139[] = { 0.22 ,0.30 ,0.40 ,0.50 ,0.60 ,0.60 ,0.70};

double Q2_Ag_E139[] = { 5.0, 5.0, 5.0 ,5.0 ,5.0 ,10.0 ,5.0};

TGraph *x_Q2_Ag_E139 = new TGraph( N, x_Ag_E139, Q2_Ag_E139);
x_Q2_Ag_E139->SetTitle("x_Q2_Ag_E139");
x_Q2_Ag_E139->SetName("");
x_Q2_Ag_E139->SetMarkerStyle(E139_marker);
x_Q2_Ag_E139->SetMarkerSize(E139_size);
x_Q2_Ag_E139->SetMarkerColor(E139_col);
x_Q2_Ag_E139->Draw("P");

// Au_E139 (18)

double x_Au_E139[] = { 0.13,0.22,0.22,0.30,0.30,0.40,0.40,0.40,
		       0.50,0.50,0.50,0.50,0.60,0.60,0.60,0.70,0.70,0.80};

double Q2_Au_E139[] = { 2.0 ,2.0, 5.0, 2.0, 5.0, 2.0 , 5.0,10.0, 
			2.0, 5.0, 5.0,10.0, 5.0,10.0,15.0, 5.0,10.0,10.0};

TGraph *x_Q2_Au_E139 = new TGraph( N, x_Au_E139, Q2_Au_E139);
x_Q2_Au_E139->SetTitle("x_Q2_Au_E139");
x_Q2_Au_E139->SetName("");
x_Q2_Au_E139->SetMarkerStyle(E139_marker);
x_Q2_Au_E139->SetMarkerSize(E139_size);
x_Q2_Au_E139->SetMarkerColor(E139_col);
x_Q2_Au_E139->Draw("P");

//_____________________________________________________________________________
// DRELL YAN 

 int DY_marker=21;
 int DY_size=1.0;
 int DY_col=9;

double Q_EXP[] = { 4.955,5.703,6.457,7.007,7.480,8.104,8.925,
		   9.785,11.34}; 

double Q2_DY[] = { 4.955*4.955,5.703*5.703,6.457*6.457,7.007*7.007,7.480*7.480,8.104*8.104,8.925*8.925,
		   9.785*9.785,11.34*11.34}; 

N = 9;

// DY_C (9)

double xT_C_DY[] = { 0.041,0.062,0.087,0.111,0.136,0.161,0.186,
		     0.216,0.269};

TGraph *xT_Q2_C_DY = new TGraph( N, xT_C_DY, Q2_DY);
xT_Q2_C_DY->SetTitle("xT_Q2_C_DY");
xT_Q2_C_DY->SetName("");
xT_Q2_C_DY->SetMarkerStyle(DY_marker);
xT_Q2_C_DY->SetMarkerSize(DY_size);
xT_Q2_C_DY->SetMarkerColor(DY_col);
xT_Q2_C_DY->Draw("P");

// DY_Ca (9)
 
double xT_Ca_DY[] = { 0.041,0.062,0.087,0.111,0.136,0.161,0.186,
		      0.216,0.269};

TGraph *xT_Q2_Ca_DY = new TGraph( N, xT_Ca_DY, Q2_DY);
xT_Q2_Ca_DY->SetTitle("xT_Q2_Ca_DY");
xT_Q2_Ca_DY->SetName("");
xT_Q2_Ca_DY->SetMarkerStyle(DY_marker);
xT_Q2_Ca_DY->SetMarkerSize(DY_size);
xT_Q2_Ca_DY->SetMarkerColor(DY_col);
xT_Q2_Ca_DY->Draw("P");

// DY_FE (9)

double xT_Fe_DY[] = { 0.041,0.062,0.087,0.111,0.136,0.161,0.186,
		      0.219,0.271};

TGraph *xT_Q2_Fe_DY = new TGraph( N, xT_Fe_DY, Q2_DY);
xT_Q2_Fe_DY->SetTitle("xT_Q2_Fe_DY");
xT_Q2_Fe_DY->SetName("");
xT_Q2_Fe_DY->SetMarkerStyle(DY_marker);
xT_Q2_Fe_DY->SetMarkerSize(DY_size);
xT_Q2_Fe_DY->SetMarkerColor(DY_col);
xT_Q2_Fe_DY->Draw("P");

// DY_W (9)

double xT_W_DY[] = { 0.041,0.062,0.087,0.111,0.136,0.161,0.186,
		     0.216,0.269};

TGraph *xT_Q2_W_DY = new TGraph( N, xT_W_DY, Q2_DY);
xT_Q2_W_DY->SetTitle("xT_Q2_W_DY");
xT_Q2_W_DY->SetName("");
xT_Q2_W_DY->SetMarkerStyle(DY_marker);
xT_Q2_W_DY->SetMarkerSize(DY_size);
xT_Q2_W_DY->SetMarkerColor(DY_col);
xT_Q2_W_DY->Draw("P");

  TLine *line = new TLine(xmin,1.,xmax,1.);
  line->SetLineColor(1);
  line->SetLineStyle(2);
  line->SetLineWidth(3);
  line->Draw();

}
