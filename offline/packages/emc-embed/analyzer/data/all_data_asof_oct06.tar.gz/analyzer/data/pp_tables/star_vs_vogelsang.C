void star_vs_vogelsang()
{
  gSystem->Load("libemcAnalyzer"); emcAnalyzer e; TGraphErrors *eband;
  e.setConstrainedHagFit(false);
  e.setFit(false);
 
  // NLO pQCD
 
  TGraphErrors *ppvogel = e.plot_spectrum_from_ascii("pQCD_ppchhad_200GeV_vogelsang.txt",eband);
  TGraphErrors *ppvogel1 = e.plot_spectrum_from_ascii("pQCD_ppchhad_200GeV_vogelsang1.txt",eband);
  TGraphErrors *ppvogel2 = e.plot_spectrum_from_ascii("pQCD_ppchhad_200GeV_vogelsang2.txt",eband);
  TGraphErrors *ppvogel0 = e.plot_spectrum_from_ascii("pQCD_ppchhad_200GeV_vogelsang0.5.txt",eband);

  emcAnalyzerUtils::scale(*ppvogel,1./2.);
  emcAnalyzerUtils::scale(*ppvogel1,1./2.);
  emcAnalyzerUtils::scale(*ppvogel2,1./2.);
  emcAnalyzerUtils::scale(*ppvogel0,1./2.);

  // Experimental data

  TGraphErrors *ppstar = e.plot_spectrum_from_ascii("h_pp_yields_NSD_star_200.txt",eband);
  double ppNSDcross = 30.;
  emcAnalyzerUtils::scale(*ppstar,ppNSDcross);
  //TGraphErrors *ppbrahms = e.plot_spectrum_from_ascii("",eband);
  //TGraphErrors *ppphnx = e.plot_spectrum_from_ascii("",eband);

  ppstar->SetMarkerStyle(30);

  // comparison

  TCanvas

  TLegend *legend = new TLegend(0.645,0.61,0.96,0.96,"STAR p+p #rightarrow h^{#pm}+X \n @ #sqrt{s} = 200 GeV","brNDC");
  legend->SetMargin(0.1);
  legend->SetTextSize(0.03);
  legend->SetFillStyle(0);
  legend->SetBorderSize(0);
  //legend->AddEntry(ppstar,"STAR NSD data","L");
  legend->AddEntry(ppvogel,"NLO pQCD (CTEQ6M, KKP, #mu=p_{T}) [W.Vogelsang]","L");
  legend->AddEntry(ppvogel1,"NLO pQCD (CTEQ6M, Kretzer, #mu=p_{T}) [W.Vogelsang]","L");
  legend->AddEntry(ppvogel2,"NLO pQCD (CTEQ6M, KKP, #mu=2p_{T}) [W.Vogelsang]","L");
  legend->AddEntry(ppvogel0,"NLO pQCD (CTEQ6M, KKP, #mu=p_{T}/2) [W.Vogelsang]","L");

  ppvogel.Draw("L")
  ppvogel0.Draw("L")
  ppvogel1.Draw("L")
  ppvogel2.Draw("L")
  legend->Draw();

  //TGraphErrors*ppvogelr=(TGraphErrors*)emcAnalyzerUtils::rebin(ppvogel,2.);
  //TGraphErrors*ppphnxr=(TGraphErrors*)emcAnalyzerUtils::rebin(ppphnx,2.);

  double ptmin=2,ptmax=12;  
  //TF1 *cole = new TF1("cole","[0]/(x^2+([1]/(log(x^2/.2)))^2)^([2]/2)", ptmin, ptmax);
  //ppphnx->Fit("cole","REIM");
    
  //TGraphErrors*rbrahmsf=(TGraphErrors*)emcAnalyzerUtils::ratioFits(ppphnx,ppbrahms);
  //TGraphErrors*rstarf=(TGraphErrors*)emcAnalyzerUtils::ratioFits(ppvogel,ppstar);

  //TGraphErrors*rbrahms=(TGraphErrors*)emcAnalyzerUtils::ratio(ppphnxr,ppbrahms);  
  TGraphErrors*rstar=(TGraphErrors*)emcAnalyzerUtils::ratio(ppvogel,ppstar,1,0.1);

  TCanvas *c = new TCanvas();
  //rbrahms->Draw("AP");
  //rbrahms->SetMarkerColor(2);
  rstar->Draw("P");
  
  TLine *line = new TLine(0.,1,17.5,1.);
  line->SetLineColor(1);
  line->SetLineStyle(2);
  line->SetLineWidth(3);
  line->Draw();

}
